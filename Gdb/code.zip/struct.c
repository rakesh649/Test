#include "header.h"
#define mem 3
typedef struct student {
    int id;
    char *name;
    int (*func)(int , int);
}stu[mem];

int add(int a, int b) {
    return a+b;
}
void fun_struct(struct student *ptr) {
    ptr[0].name=(char *)calloc(1,64);
    printf("Enter id and name\n");
    scanf("%d %s",&ptr[0].id,ptr[0].name);
    printf("%d %s\n",ptr[0].id,ptr[0].name);
    strcpy(ptr[0].name,"Rakesh");
    ptr[0].func=add;
}
void structure() {
    int res=0;
    struct student var[mem],*ptr;
    ptr=var;
    fun_struct(ptr);
    printf("Updated name = %s\n",ptr[0].name);
    res=ptr[0].func(2,3);
    printf("Res = %d\n",res);
    return 0;
}