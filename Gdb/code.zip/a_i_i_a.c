
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int uatoi(char *str) {
    int i,num=0;
    for(i=0;str[i];i++) {
        if('0' <= str[i] && str[i] <= '9')
            continue;
        else
            return 0;
    }
    
    for(i=0;str[i];i++) {
        num=num*10+str[i]-48;
    }
    return num;
}

char *uitoa(int n) {
    char *str;
    int i=0,j=0;
    str=calloc(1,64);
    while(n) {
        str[i++]=n%10 + 48;
        // printf("n = %d and str[i] = %c\n",n,str[i]);
        n/=10;
    }
    str[i]='\0';
    // printf("str = %s\n",str);
    for(i=0,j=strlen(str)-1;i<j;i++,j--) {
        str[i]=str[i]^str[j];
        str[j]=str[i]^str[j];
        str[i]=str[i]^str[j];
    }
    return str;
}

void atoi_itoa()
{
    char str[64],*str1;
    int res=0;
    printf("Enter string to convert to int\n");
    scanf("%s",str);
    res=uatoi(str);
    printf("Integer = %d\n",res);
    printf("Enter Integer to convert to ascii\n");
    scanf("%d",&res);
    str1=uitoa(res);
    printf("String = %s\n",str1);
    return ;
}
