#include "header.h"
#define row 2
#define col 2
//rakesh => s r k h e a
void sort_descending(char *str) {
    int i,j;
    for(i=0;str[i];i++) {
        for(j=i+1;str[j];j++) {
            if(str[i] < str[j]) {
                str[i]=str[i]^str[j];
                str[j]=str[i]^str[j];
                str[i]=str[i]^str[j];
            }
        }
    }
}
void sort_str() {
    char str[64];
    printf("Enter string to be sorted\n");
    scanf("%s",str);
    printf("Before sorting : %s\n",str);
    sort_descending(str);
     printf("After sorting : %s\n",str);
}




void mul_matrices() {
    int a[row][col],b[row][col],c[row][col],i,j,k;
    printf("Enter elements for matrix a\n");
    for(i=0;i<row;i++) {
        for(j=0;j<col;j++) {
            scanf("%d",&a[i][j]);
        }
    }
    
    printf("Enter elements for matrix b\n");
    for(i=0;i<row;i++) {
        for(j=0;j<col;j++) {
            scanf("%d",&b[i][j]);
        }
    }
    
   
    for(i=0;i<row;i++) {
        for(j=0;j<col;j++) {
            for(k=0;k<col;k++) {
                c[i][j]+=a[i][k]*b[k][j];
            }
        }
    }
    
    printf("Multiplication of matrix a&b\n");
    for(i=0;i<row;i++,printf("\n")) {
        for(j=0;j<col;j++) {
            printf("%d ",c[i][j]);
        }
    }
}


void add_matrices() {
     int a[row][col],b[row][col],c[row][col],i,j;
     
    printf("Enter elements for matrix a\n");
    for(i=0;i<row;i++) {
        for(j=0;j<col;j++) {
            scanf("%d",&a[i][j]);
        }
    }
    
    printf("Enter elements for matrix b\n");
    for(i=0;i<row;i++) {
        for(j=0;j<col;j++) {
            scanf("%d",&b[i][j]);
        }
    }
    
    for(i=0;i<row;i++) {
        for(j=0;j<col;j++) {
                c[i][j]=a[i][j]+b[i][j];
        }
    }
    
    printf("Addition of matrix a&b\n");
    for(i=0;i<row;i++,printf("\n")) {
        for(j=0;j<col;j++) {
            printf("%d ",c[i][j]);
        }
    }
}

int isprime(int n) {
    int i;
    if(n == 0 | n == 1)
        return 0;
    if(n == 2)
        return 1;
    for(i=2;i<n;i++) {
        if(n%i == 0)
            return 0;
    }
    return 1;
}
void prime_num() {
    int n;
    printf("Enter number to check prime or not\n");
    scanf("%d",&n);
    if(isprime(n))
        printf("%d: is prime\n",n);
    else
        printf("%d: is not a prime\n",n);
}