#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void sort_str();
void mul_matrices();
void add_matrices();
void prime_num();

void num_add_str();

void atoi_itoa();
void num_conversion();

void stack_queue();

void circular_shift();
void structure();