#include "header.h"

void right_shift(int *num,int bit0) {
    bit0=*num&1;
    *num=*num>>1;
    *num=*num|(bit0 << 31);
}
void left_shift(long int *ptr,int bit31) {
    if(*ptr&(1<<31))
        bit31=1;
    *ptr=*ptr<<1;
    *ptr=*ptr|bit31;
}
static void display(int num) {
    int i;
    for(i=0;i<=31;i++) {
        if(num & (1 << 31-i))
            printf("1 ");
        else
            printf("0 ");
        // num=num>>1;
    }
}
int str_polindrome(char *str) {
    int i,j=strlen(str)-1;
    for(i=0,j;i<=j;i++,j--) {
        if(str[i] == str[j])
            continue;
        else 
            return 0;
    }
    return 1;
}
int fib(int n) {
    if(n == 0)
        return 0;
    if(n == 1)
        return 1;
    
    return fib(n-1)+fib(n-2);
   
}
void circular_shift()
{
    // long int num=0,posn=0,mask=1,bit0=0,bit31=0,i=0;
    
    // printf("Enter number and posn\n");
    // scanf("%ld %ld",&num,&posn);
    // display(num);
    // printf("After change\n");
    // for(i=0;i<posn;i++) {
    //     right_shift(&num,bit0);
    // }
    // display(num);
    // for(i=0;i<posn;i++) {
    //     left_shift(&num,bit31);
    // }
    // printf("After left shift\n");
    //  display(num);
    // int ret=0;
    // char str[64];
    // printf("Enter string \n");
    // scanf("%s",str);
    // ret=str_polindrome(str);
    // if(ret == 1)
    //     printf("%s: is a polindrome\n",str);
    int n,ret=0,i;
    printf("Enter series length\n");
    scanf("%d",&n);
    printf("0 1 ");
    for(i=2;i<n;i++) {
        ret=fib(i);
        printf("%d ",ret);
    }
    return ;
}