#include "header.h"

char *add_str(char *str1,char *str2) {
    int i,j,car=0,num=0,k=0,len=0,itr=0,digit=0;
    i=strlen(str1);
    j=strlen(str2);
    len=(i>j?i:j);
    // printf("len = %d\n",len);
    char *str3=calloc(1,(len + 2)*sizeof(char));
    for(itr=len-1;itr>=0;itr--) {
        num=str1[itr]-48+str2[itr]-48+car;
        digit=num%10;
        // printf("num = %d digit = %d str1 = %c str2 = %c\n",num,digit,str1[i],str2[i]);
        car=num/10;
        str3[k++]=digit+48;
    }
    if(car == 1) {
        str3[k++]=car+48;
        str3[k]='\0';
    }
    // printf("before reverse str3 = %s\n",str3);
    for(i=0,j=strlen(str3)-1;i<j;i++,j--) {
        str3[i]=str3[i]^str3[j];
        str3[j]=str3[i]^str3[j];
        str3[i]=str3[i]^str3[j];
    }
    return str3;
    // printf("after reverse str3 = %s\n",str3);
}
void num_add_str() {
    char str1[64],str2[64],*str3;
    scanf("%s %s",str1,str2);
    str3=add_str(str1,str2);
    printf("sum of two numbers = %s\n",str3);
    free(str3);
}