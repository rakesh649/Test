/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

/*
1
3
1 
2
1

o/p
2



1
5
1
1
2
2
3 

3
*/

#include "header.h"

int check_done(int x,int *arr,int n) {
    int i;
    for(i=0;i<n;i++) {
        if(arr[i] == x)
            return 1;
    }
    return 0;
}
int check_for_cmp(int i,int *arr,int n) {
    int j,*arr1,ret=0;
    static int cnt=0;
    ret=check_done(arr[i],arr1,cnt);
    if(ret == 1)
        return 0;
    for(j=i+1;j<n;j++) {
        if(arr[i] == arr[j]) {
            arr1=realloc(arr1,(cnt+1)*sizeof(int));
            arr1[cnt]=arr[j];
            cnt++;
            return 0;
        }            
    }
    return -1;
}
int main(void) {
	// your code goes here
// 	int t,n,i=0,j=0,res=0;
// 	printf("Enter size of array and no of test cases\n");
// 	scanf("%d %d",&n,&t);
// 	int arr[n];
// 	while(j<t) {
// 	    for(i=0;i<n;i++) {
// 	        scanf("%d",arr+i);
// 	    }
// 	    for(i=0;i<n;i++) {
// 	        res=check_for_cmp(i,arr,n);
// 	        if(res == -1) {
// 	            printf("SINGLE LD = %d",arr[i]);
// 	            break;
// 	        }
// 	    }
// 	    j++;
// 	}
    // sort_str();
    // mul_matrices();
    // add_matrices();
    // prime_num();
    // num_add_str();
    
    // atoi_itoa();
    // num_conversion();
    
    // stack_queue();
    // circular_shift();
    structure();
}




