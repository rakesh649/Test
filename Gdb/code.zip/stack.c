#include "header.h"
#define max 5
typedef struct stk {
    int val;
    struct stk *link;
}stk;
stk *top=NULL;
// stk *que;
typedef struct stk que;
que *head=NULL;
void push(int n) {
    static int limit=0;
    stk *new=NULL;
    if(limit <= max) {
        new=(stk *)calloc(1,sizeof(stk));
        if(new == NULL) {
            fprintf(stderr,"Memory allocation failed\n");
            return NULL;
        }
        limit++;
        new->val=n;
        if(top == NULL) 
            top=new;
        else {
            new->link=top;
            top=new;
        }
    }
    else
         printf("STACK IS FULL after =%d\n",top->val);
}
int pop() {
    stk *temp=NULL;
    int data=0;
    printf("top = %p\n",top);
    if(top) {
        data=top->val;
        temp=top;
        top=top->link;
        free(temp);
        return data;
    }
    return -1;
}
void stack() {
    int val=0,i;
    for(i=0;i<=max;i++)
        push(i);
    // push(20);
    for(i=0;i<=8;i++) {
         val=pop();
        if(val == -1)
            printf("Stack is empty\n");
        else {
            printf("Popped data is %d\t",val);
            // printf("Current top = %d\n",top->val);
        }
    }
}
void Enqueue(int n) {
    // stk que;
    que *newnode=NULL,*temp=NULL;
    newnode=(que *)calloc(1,sizeof(que));
    newnode->val=n;
    if(top == NULL) {
        top=newnode;
        head=newnode;
    }
    else {
        for(temp=head;temp->link != NULL;temp=temp->link);
        temp->link=newnode;
        top=newnode;
    }
}
void display(que *ptr) {
    while(ptr) {
        printf("val = %d\n",ptr->val);
        ptr=ptr->link;
    }
}
int peek() {
    return top->val;
}
int Dequeue() {
    int val=0;
    que *temp=NULL;
    if(head) {
        val=head->val;
        temp=head;
        head=head->link;
        free(temp);
        return val;
    }
    else {
        printf("queue is empty\n");
        return -1;
    }
    
}
void queue() {
    int pop=0;
    Enqueue(10);
    Enqueue(20);
    Enqueue(30);
    display(head);
    printf("peek = %d\n",peek());
    pop=Dequeue();
    if(pop == -1)
        printf("No element present\n");
    else 
        printf("Dequeue element = %d\n",pop);
    printf("Remaining elements in queue are\n");
    display(head);
}
stack_queue() {
    // stack();
    queue();
}