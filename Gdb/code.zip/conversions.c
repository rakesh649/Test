#include "header.h"
#include <math.h>

void dec_binary() {
    int n,res=0,mul=1;
    printf("Enter decimal number\n");
    scanf("%d",&n);
    while(n) {
        res=res+n%2*mul;
        mul=mul*10;
        n/=2;
    }
    printf("Resultant binary is = %d\n",res);
}
void dec_hex() {
    int n,res=0,mul=1;
    printf("Enter decimal number\n");
    scanf("%d",&n); 
    if(0 <= n && n <= 9) {
        res=n;
        goto end;   
    }
    while(n) {
        res=res+n%16*mul;
        mul=mul*10;
        n/=16;
    }
    end:
    printf("Resultant hex is = %d\n",res);
}
void bin_decimal() {
    long long int bin=0;
    int dec=0,i=0;
    printf("Enter binary\n");
    scanf("%llu",&bin);
    while(bin) {
        dec=dec+bin%10*pow(2,i);
        bin/=10;
        i++;
    }
    printf("Resultant decimal is = %d\n",dec);
}

void hex_decimal() {
    long int hex=0;
    int dec=0,i=0;
    printf("Enter hex number\n");
    scanf("%d",&hex);
    while(hex) {
        dec=dec+hex%10*pow(16,i++);
        hex/=10;
    }
    printf("Resultant decimal from hex = %d\n",dec);
}
void num_conversion() {
    // dec_binary();
    // dec_hex();
    // bin_decimal();
    // hex_decimal();
}