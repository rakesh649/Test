/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include "header.h."

int main()
{
    // rm_duplicates();
    
    // bst();
    // rm_occur_ele();
    
    // ternary();
    // check_setbit();
    // str_polindrome();
    // Max_occur_word_str();
    
    // common_arr_ele();
    // rotate_arr();
    
    // sort_mat_row();
    // concatinate();
    // add_bin_str();
    
    // Non_repeat_char();
    // rev_str_recur();
    
    // len_str();
    // logest_prime();
    
    // sort_str();
    // fst_let_word();
    // u_strtok();
    
    // fun_ret_ptr();
    // sort_words_str();
    // highest_el_arr();
    
    // student_info();
    
    cp_onefile_secfile();
    return 0;
}
