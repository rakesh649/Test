#include"header.h."

void rm_occur_ele() {
    int num=0,ele=0,*arr,i=0,j=0;
    printf("Enter size of array and ele\n");
    scanf("%d %d",&num,&ele);
    arr=(int *)calloc(num,sizeof(int));
    for(i=0;i<num;i++)
        scanf("%d",arr+i);
        printf("Processing data\n");
    for(i=0;i<num;i++) {
        if(arr[i] == ele) {
            j=i;
            // printf("Element matched at index %d\n",j);
            arr=realloc(arr,(num-1)*sizeof(int));
            while(j<num-1) {
                arr[j]=arr[j+1];
                j++;
            }
            num--;
            i--;
        }
    }
    for(i=0;i<num;i++)
        printf("%d ",arr[i]);
    free(arr);
}

void rm_duplicates() {
    int len=5;
    int arr[5],i=0,j=0,k=0;
    printf("Enter arr elements\n");
    for(i=0;i<len;i++)
        scanf("%d",arr+i);
    
    for(i=0;i<len;i++) {
        for(j=i+1;j<len-i;j++) {
            if(arr[i] == arr[j]) {
                k=j;
                while(k<(len-1)) {
                    arr[k]=arr[k+1];
                    k++;
                }
                j--;
                len--;
            }
        }
    }
    for(i=0;i<len;i++)
        printf(".%d ",arr[i]);
}

typedef struct bst {
    int num;
    struct bst *left;
    struct bst *right;
}bt;
bt *head=NULL;
void add(int n) {
    bt *newnode=NULL,*temp=NULL,*prev=NULL;
    newnode=(bt *)calloc(1,sizeof(bt));
    newnode->num=n;
    
    if(head == NULL)
        head=newnode;
    else {
        temp=head;
        while(temp) {
            prev=temp;
            if(temp->num > n) 
                temp=temp->left;
            else
                temp=temp->right;
        }
        
        if(n > prev->num)
            prev->right=newnode;
        else
           prev->left=newnode; 
    }
    
}
void display(bt *ptr) {
    // while(ptr) {
        printf("num = %d\n",ptr->num);
        // ptr=ptr->left;
    // }
}
void preorder(bt *ptr) {
    if(ptr == NULL)
        return;
    
    preorder(ptr->left);
    printf("num = %d\n",ptr->num);
    preorder(ptr->right);
    // preorder(ptr->right);
}
void bst() {
    add(10);
    add(6);
    add(5);
    add(7);
    add(20);
    preorder(head);
}


void ternary() {
    int a,b,c;
    printf("Enter 3 numbers\n");
    scanf("%d %d %d",&a,&b,&c);
    (a>b)?(a>c)?printf("%d is max\n",a):printf("%d is max",c):(b>c)?printf("%d is max",b):printf("%d is max",c);
}


void check_setbit() {
    int num;
    printf("Enter number\n");
    scanf("%d",&num);
    if(num & 1 )
        printf("LSB bit is set\n");
    else
        printf("LSB bit is not set\n");
        
    if(num & 1 << 31)
        printf("MSB bit is set\n");
    else
        printf("MSB bit is not set\n");
    
}


void str_polindrome() {
    char str[64];
    int i,j;
    printf("Enter string\n");
    scanf("%s",str);
    j=strlen(str)-1;
    for(i=0,j;i<j;i++,j--) {
        if(str[i] == str[j]) 
            continue;
        else
            break;
    }
    if(i>=j)
        printf("%s: is a polindrom\n",str);
    else
        printf("%s: is NOT a polindrom\n",str);
}

int check_equality(char *sub_st,char *sub_end,char *st, char *end) {
    int i=0;
    printf(" sub_st = %c sub_end = %c with st = %c end = %c\n",*sub_st,*sub_end,*st,*end);
    while(st <= end) {
        if(*sub_st++ != *st++)
        return 0;
    }
    return 1;
}
void check_freq(char *str1,char *st ,char *end) {
    int i,match=0,res=0,j=0;
    char match_str[32],*sub_st,*sub_end,*lc;
    
    printf("Remaining str = %s with st = %c end = %c\n",str1,*st,*end);
    for(i=0;i<=strlen(str1);i++) {
        if((st <= str1) && (str1 <= end)) {
            continue;
        }
        sub_st=sub_end=str1+1;
        printf("in sub st = %c sub end = %c\n",*sub_st,*sub_end);
        if(str1[i] == ' ' || str1[i] == '\0') {
            res=check_equality(sub_st,sub_end-1,st,end);
            printf("res = %d st is at = %c\n",res,*st);
            if(res == 1) {
                match++;
                lc=st;
                while(lc <= end) {
                    match_str[j++]=*lc++;
                }
                match_str[j]='\0';
                printf("match_str = %s\n",match_str);
            }
            sub_st=str1+i+1;
        }
        sub_end++;
    }
}
void check_for_word(char *str) {
    char *st=NULL,*end=NULL;
    int i;
    st=end=str;
    for(i=0;i<=strlen(str);i++) {
        if(str[i] == ' ') {
            
            check_freq(str,st,end-1);
            st=str+i+1;
        }
        end++;
    }
}
void Max_occur_word_str() {
    char str[64];
    printf("Enter string\n");
    scanf("%[^\n]s",str);
    check_for_word(str);
    // printf("str = %s\n",str);
}

#define len1 5
#define len2 5
void common_arr_ele() {
    int arr[len1],arr1[len2],i,j,res[100]={0},k=0,flag=0,x=0;
    printf("Enter  arr1 elements\n");
    for(i=0;i<len1;i++)
        scanf("%d",arr+i);
        
    printf("Enter  arr2 elements\n");
    for(i=0;i<len2;i++)
        scanf("%d",arr1+i);
        
    // printf("Common elements are: ");
    for(i=0;i<len1;i++) {
        for(j=0;j<len2;j++) {
            if(arr[i] == arr1[j]) {
                
                for(x=0;x<k;x++) {
                    if(arr[i] ==  res[x])
                        flag=1;
                }
                
                if(flag == 0) {
                    res[k]=arr[i];
                    k++;
                }
                    
            }
                
        }
    }
    printf("Common elements are:");
    for(i=0;i<k;i++)
        printf("%d ",res[i]);
}

void rotate_arr() {
    int arr[len1],n,temp=0,i=0,j=0;
     printf("Enter arr elements\n");
     for(i=0;i<len1;i++)
        scanf("%d",arr+i);
    printf("Enter number of times arr should be rotated\n");
    scanf("%d",&n);
    for(i=0;i<n;i++) {
        temp=arr[0];
        for(j=0;j<len1;j++) 
            arr[j]=arr[j+1];
        arr[len1-1]=temp;
    }
    for(i=0;i<len1;i++)
        printf("%d ",arr[i]);
}

#define row 3
#define col 3
void sort_mat_row() {
    int i=0,j=0,arr[row][col]={0};
    printf("Enter arr elements\n");
    for(i=0;i<row;i++) {
        for(j=0;j<col;j++) {
            scanf("%d",&arr[i][j]);
        }
    }
    
    
    printf("Printing arr elements\n");
    for(i=0;i<row;i++,printf("\n")) {
        for(j=0;j<col;j++) {
            printf("%d ",arr[i][j]);
        }
    }
    
    printf("sorting arr elements\n");
    for(i=0;i<row;i++) {
        for(j=0;j<col-1;j++) {
            if(arr[i][j] > arr[i][j+1]) {
                arr[i][j]=arr[i][j]^arr[i][j+1];
                arr[i][j+1]=arr[i][j]^arr[i][j+1];
                arr[i][j]=arr[i][j]^arr[i][j+1];
            }
        }
    }
    
    printf("Printing after sorting elements\n");
    for(i=0;i<row;i++,printf("\n")) {
        for(j=0;j<col;j++) {
            printf("%d ",arr[i][j]);
        }
    }
}