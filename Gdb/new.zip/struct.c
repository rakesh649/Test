#include"header.h."
#define size 5
typedef struct stu {
    int num;
    char str[64];
    // struct stu *link;
}stu;

// stu *head=NULL;
void sort_mem(stu *ptr) {
    int i,j;
    stu temp;
   for(i=0;i<size;i++) {
       for(j=i+1;j<size;j++) {
           if(strcmp(ptr[i].str,ptr[j].str) > 0) {
                temp=ptr[i];
                ptr[i]=ptr[j];
                ptr[j]=temp;
           }
       }
   }
    // printf("%d %s\n",ptr[i].num,ptr[i].str); 
}
void student_info() {
    stu *arr;
    int i;
    arr=(stu *)calloc(size,sizeof(stu));
    for(i=0;i<size;i++) {
        printf("Enter num & name\n");
        scanf("%d %s",&arr[i].num,arr[i].str);
    }
    printf("Before sorting\n");
    for(i=0;i<size;i++)
        printf("%d %s\n",arr[i].num,arr[i].str);
    
    printf("After sorting\n");    
    sort_mem(arr);
    for(i=0;i<size;i++)
        printf("%d:name =  %s num = %d\n",i,arr[i].str,arr[i].num);

}

void cp_onefile_secfile() {
    FILE *fp1,*fp2;
    char ch;
    fp1=fopen("./file1","r");
    if(fp1 != NULL) {
        fp2=fopen("./file2","r");
        if(fp2 != NULL) {
            while(ch=fgetc(fp1) != EOF)
                fputc(ch,fp2);
        }
    }
    fclose(fp1);
    fclose(fp2);
}