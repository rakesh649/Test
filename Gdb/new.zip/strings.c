#include"header.h." 

void concatinate() {
    char str[64],str1[64];
    int i=0,j=0,len=0;
    printf("Enter 2 strings\n");
    scanf("%s %s",str,str1);
    i=strlen(str);
    for(j=0;str1[j];j++)
        str[i++]=str1[j];
    str[i]='\0';
    printf("Output str = %s\n",str);
}
static void rev_str(char *str3) {
    int i,j=0;
    j=strlen(str3)-1;
    for(i=0,j;i<j;i++,j--) {
        str3[i]=str3[i]^str3[j];
        str3[j]=str3[i]^str3[j];
        str3[i]=str3[i]^str3[j];
    }
}
void add_bin_str() {
    char str1[16],str2[16],str3[16];
    int len1=0,len2=0,i=0,j=0,k=0,c=0,sum=0,len=0;
    printf("Enter two strings\n");
    scanf("%s %s",str1,str2);
    len1=strlen(str1);
    len2=strlen(str2);
    (len1>len2)?(len=len1):(len=len2);
    for(i=len1-1,j=len2-1;len>0;i--,j--,len--) {
        sum=((i<0)?('0'):(str1[i])-'0')+((j<0)?('0'):(str2[j])-'0')+c;
        // printf("sum = %d\n",sum);
        if(sum > 1) 
            c=1;
        str3[k++]=(sum%2 == 0)?('0'):('1');
        // printf("char sum = %c\n",str3[k-1]);
    }
    if(c == 1)
        str3[k++]='1';
    str3[k]='\0';
    rev_str(str3);
    printf("str3 = %s\n",str3);
}

void Non_repeat_char() {
    char str[64];
    int i,j,flag=0;
    printf("Enter string\n");
    scanf("%s",str);
    for(i=0;str[i];i++) {
        for(j=0;str[j];j++) {
            // printf("%c = %c\n",str[i],str[j]);
            if(str[i] == str[j])
                flag++;
        }
        if(flag == 1) {
                printf("Fst Non repeating char = %c\n",str[i]);
                goto end;
        }
        flag=0;
    }
    printf("All characters are repeating\n");
    end:
}
 void reverse_str(char *str, char *res, int i,int n) {
    // static int i=0;
    if(*str)
        reverse_str(str+1,res,i+1,n);
    else 
        return;
    res[n-i]=*str;
    printf("%c",*str);
}
void rev_str_recur() {
    char str[64],res_str[64];
    int i=0,n=0;
    printf("Enter string\n");
    scanf("%s",str);
    n=strlen(str);
    reverse_str(str,res_str,i,n-1);
    printf("res str = %s\n",res_str);
}


void len_str() {
    int cnt=0;
    char str[64];
    printf("Enter str\n");
    scanf("%s",str);
    while(str[cnt])
        ++cnt;
    printf("Len of str = %d\n",cnt);
}


int isprime(int n) {
    int i;
    if(n == 0 || n == 1)
        return 0;
    if(n == 2)
        return 1;
    for(i=2;i<n;i++) {
        if(n%i == 0)
            return 0;
    }
    return 1;
}
long int rev_num(long int n) {
    long int sum =0;
    while(n) {
        sum=sum*10+n%10;
        // printf("sum = %ld rem = %ld\n",sum,n%10);
        n=n/10;
    }
   return sum;
}


void logest_prime() {
    
    long int num=0,rev=0,x=0,l_p=0,max=0;
    int res=0,digit=0;
    printf("Enter number\n");
    scanf("%ld",&num);
    rev=rev_num(num);
    //  printf("rev = %ld\n",rev);
    while(rev) {
        // printf("For each digit = %ld\n",rev%10);
        x=rev;
        l_p=0;
        while(x) {
            digit=x%10;
            // printf("digit = %d\n",digit);
             l_p=l_p*10+digit;
             res=isprime(l_p);
             if(res == 1) {
                if(l_p > max || (max == 0))
                    max=l_p;
                
             }
            x=x/10;
        }
        rev=rev/10;
    }
    printf("curr max = %ld\n",max);
}

void sort_str() {
    char str[64];
    int i,j;
    printf("Enter str\n");
    scanf("%s",str);
    for(i=0;str[i];i++) {
        for(j=i+1;str[j];j++) {
            if(str[i] > str[j]) {
                str[i]=str[i]^str[j];
                str[j]=str[i]^str[j];
                str[i]=str[i]^str[j];
            }
        }
    }
    printf("Sorted str = %s\n",str);
}

void fst_let_word() {
    int i=0;
    char str[64];
    printf("Enter str\n");
    scanf("%[^\n]s",str);
    for(i=0;str[i];i++) {
        if(i == 0 && str[i] != ' ')
            printf("%c ",str[0]);
        if(str[i] == ' ' && str[i+1] != ' ')
            printf("%c ",str[i+1]);
    }
}

char *user_strtok(char *str,char ch) {
    int i;
    static char *next;
    // printf("str = %s\n",str);
    if(str != NULL) {
        for(i=0;str[i];i++) {
            if(str[i] == ch) {
                next=str+i+1;
                str[i]='\0';
                return str;
            }
        }
        
    }
    else {
       str=next; 
    //   printf("next = %s\n",str);
       for(i=0;str[i];i++) {
            if(str[i] == ch) {
                next=str+i+1;
                str[i]='\0';
                return str;
            }
        }
        if(str[i] == '\0') {
            next=NULL;
            return str;
        }
            
    }
}
void u_strtok() {
    char str[64],del,*ptr;
    printf("Enter str\n");
    scanf("%[^\n]s",str);
    while(getchar() != '\n');
    scanf("%c",&del);
    ptr=user_strtok(str,del);
    printf("fst = %s\n",ptr);
    while(ptr) {
        ptr=user_strtok(NULL,del);
        printf("ptr = %s\n",ptr);
    }
    
}

static int *fun(int *ptr) {
    return ptr;
}
void fun_ret_ptr() {
    int x=10,*ptr,*ret;
    ptr = &x;
    ret=fun(ptr);
    printf("Val = %d\n",*ret);
}

void sor_ting(char **ptr , int n) {
    int i=0;
    for(i=0;i<n;i++) {
     printf("*ptr = %s addr = %p\n",ptr[i],ptr[i]);
    }
}
void print(char **str,int n) {
  int i;
  for(i=0;i<n;i++)
    printf("%d:%s\n",i,str[i]);
}
void sort_words_str() {
 int n,i,j,len=0;
 printf("Enter num of strings\n");
 scanf("%d",&n);
 
 char **str,temp[16];
 str=(char **)calloc(n,sizeof(char *));
 
 for(i=0;i<n;i++) {
    str[i]=(char *)calloc(n,16);
     scanf("%s",str[i]);
 }

 for(i=0;i<n;i++) {
     for(j=i+1;j<n;j++) {
        //   printf("str = %s str = %s\n",str[i],str[j]);
         len=strcmp(str[i],str[j]);
        //  printf("len = %d\n",len);
         if(len > 0) {
            strcpy(temp,str[i]);
            strcpy(str[i],str[j]);
            strcpy(str[j],temp);
            
        }
     }
 }
 
 print(str,n);
 
  for(i=0;i<n;i++) 
    free(str[i]);
    
    free(str);
    
}

void highest_el_arr() {
    int *arr,i,j,n,max=0,sec_max=0;
    printf("Enter number of ele's in an arr\n");
    scanf("%d",&n);
    
    arr=(int *)calloc(1,n*sizeof(int));
    for(i=0;i<n;i++)
        scanf("%d",arr+i);
    max=arr[0],sec_max=arr[0];
    for(i=0;i<n;i++) {
        if((arr[i] > max) && arr[i] != max) 
            max=arr[i];
        else if((arr[i] > sec_max) && (arr[i] != sec_max))
            sec_max=arr[i];
    }
        
    printf("max = %d sec_max = %d\n",max,sec_max);
}